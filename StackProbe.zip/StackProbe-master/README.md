# StackProbe
Web plateform which gives you facility to campare popularity of different technology based on big data analysis of stack overflow website. The result was produced by Hadoop Cluster and shown to user by using web plateform developed using HTML,CSS,Bootsrap. At back end it is supported by PHP,MySQL
