<html>
<body>
Hell-9
 <?php echo $_POST['firstTech']; ?><br>
 <?php echo $_POST['secondTech']; ?>

</body>
</html>